/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_334(unsigned *p)
{
    *p = 414447970U;
}

unsigned addval_323(unsigned x)
{
    return x + 3277348731U;
}

unsigned addval_434(unsigned x)
{
    return x + 3351742792U;
}

unsigned getval_407()
{
    return 3347662938U;
}

unsigned addval_117(unsigned x)
{
    return x + 1562887032U;
}

unsigned addval_136(unsigned x)
{
    return x + 3284633928U;
}

void setval_322(unsigned *p)
{
    *p = 2462550344U;
}

void setval_209(unsigned *p)
{
    *p = 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_466(unsigned x)
{
    return x + 3375944072U;
}

unsigned addval_108(unsigned x)
{
    return x + 3284314486U;
}

unsigned getval_293()
{
    return 1674038921U;
}

unsigned addval_102(unsigned x)
{
    return x + 3767093399U;
}

void setval_497(unsigned *p)
{
    *p = 3515430034U;
}

unsigned addval_467(unsigned x)
{
    return x + 3676360329U;
}

unsigned addval_148(unsigned x)
{
    return x + 3531132553U;
}

unsigned addval_195(unsigned x)
{
    return x + 2425409931U;
}

void setval_481(unsigned *p)
{
    *p = 3531915912U;
}

void setval_317(unsigned *p)
{
    *p = 3286272330U;
}

void setval_370(unsigned *p)
{
    *p = 3269495112U;
}

void setval_145(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_104()
{
    return 3286288712U;
}

void setval_255(unsigned *p)
{
    *p = 3467192953U;
}

unsigned getval_432()
{
    return 3767093968U;
}

unsigned getval_129()
{
    return 3674263945U;
}

unsigned getval_433()
{
    return 3353381192U;
}

void setval_227(unsigned *p)
{
    *p = 3888366233U;
}

unsigned addval_420(unsigned x)
{
    return x + 2446231832U;
}

void setval_401(unsigned *p)
{
    *p = 3221799561U;
}

unsigned getval_465()
{
    return 3380920841U;
}

void setval_101(unsigned *p)
{
    *p = 3525366217U;
}

unsigned getval_339()
{
    return 3526413961U;
}

unsigned addval_275(unsigned x)
{
    return x + 3674784409U;
}

void setval_180(unsigned *p)
{
    *p = 3674787465U;
}

void setval_319(unsigned *p)
{
    *p = 3375940233U;
}

void setval_184(unsigned *p)
{
    *p = 3676361097U;
}

void setval_156(unsigned *p)
{
    *p = 3281047944U;
}

unsigned addval_441(unsigned x)
{
    return x + 3767093262U;
}

unsigned getval_447()
{
    return 2446428439U;
}

unsigned getval_188()
{
    return 3674263177U;
}

unsigned addval_258(unsigned x)
{
    return x + 3525886601U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
